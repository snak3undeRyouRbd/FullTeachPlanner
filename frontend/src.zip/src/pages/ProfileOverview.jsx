import React from 'react';

const ProfileOverview = () => {
  return (
    <div>
      <h2>Огляд Профілю</h2>
      <p>Тут основна інформація про користувача.</p>
    </div>
  );
};

export default ProfileOverview;