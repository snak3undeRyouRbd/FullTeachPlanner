import React from 'react';
import Navbar from '../components/Navbar';
import SiteFooter from '../components/SiteFooter';

const Settings= () => {

  
  return (
    <div>
		<Navbar />
		<h1>Налаштування</h1>
    <SiteFooter />
    </div>
  );
};

export default Settings;