import React from 'react';

const ProfileSettings = () => {
  return (
    <div>
      <h2>Налаштування Профілю</h2>
      <p>Тут опції налаштувань профілю.</p>
    </div>
  );
};

export default ProfileSettings;