import React from 'react';

const ProfileEdit = () => {
  return (
    <div>
      <h2>Редагувати Профіль</h2>
      <p>Тут поля для редагування інформації профілю.</p>
    </div>
  );
};

export default ProfileEdit;