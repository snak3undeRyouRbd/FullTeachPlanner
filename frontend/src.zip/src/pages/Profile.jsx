import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import ProfileForm from '../components/ProfileForm';
import SiteFooter from '../components/SiteFooter';
import Navbar from '../components/Navbar';

const Profile = () => {
  const location = useLocation();
  const isSubMenuActive = (path) => {
      return location.pathname === path ? 'active' : '';
  };

   const isOverviewActive = () => {
       return location.pathname === '/profile' ? 'active' : '';
   };


  return (
    <div>
      <Navbar />
      <h1>Профіль користувача</h1>

      <nav>
        <ul className="nav nav-tabs mb-4">
          <li className="nav-item">
            <Link
              className={`nav-link ${isOverviewActive()}`}
              to="/profile"
              style={{ padding: '0.5rem 1rem' }}
            >
              Огляд
            </Link>
          </li>
          <li className="nav-item">
            <Link
              className={`nav-link ${isSubMenuActive('/profile/edit')}`}
              to="/profile/edit"
              style={{ padding: '0.5rem 1rem' }}
            >
              Редагувати
            </Link>
          </li>
          <li className="nav-item">
            <Link
              className={`nav-link ${isSubMenuActive('/profile/settings')}`}
               to="/profile/settings"
               style={{ padding: '0.5rem 1rem' }}
            >
              Налаштування
            </Link>
          </li>
        </ul>
      </nav>

      <div className="profile-content">
        <ProfileForm />
      </div>
      <SiteFooter />
    </div>
  );
};

export default Profile;